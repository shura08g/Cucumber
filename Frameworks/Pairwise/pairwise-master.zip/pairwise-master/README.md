Pairwise
-------

[![Code Climate](https://codeclimate.com/badge.png)](https://codeclimate.com/github/josephwilk/pairwise)
[![Build Status](https://secure.travis-ci.org/josephwilk/pairwise.png)](http://travis-ci.org/josephwilk/pairwise)

How to use Pairwise: http://josephwilk.github.com/pairwise/

Running tests
------------
<pre><code>rake</code></pre>


Copyright
--------

Copyright (c) 2009,2010,2011,2012 Joseph Wilk. See LICENSE for details.
