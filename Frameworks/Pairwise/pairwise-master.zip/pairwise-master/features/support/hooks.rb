Before do
  Kernel.stub!(:rand).and_return(0)
end

