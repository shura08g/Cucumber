%w[cucumber csv].each {|file| require "pairwise/formatter/#{file}"}
