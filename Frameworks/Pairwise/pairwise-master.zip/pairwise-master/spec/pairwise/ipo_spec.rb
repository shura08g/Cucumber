require 'spec_helper'

module Pairwise
  describe IPO do

  end
end
