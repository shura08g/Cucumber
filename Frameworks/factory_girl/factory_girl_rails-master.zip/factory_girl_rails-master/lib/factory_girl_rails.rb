require 'factory_girl_rails/railtie'

module FactoryGirlRails
end
