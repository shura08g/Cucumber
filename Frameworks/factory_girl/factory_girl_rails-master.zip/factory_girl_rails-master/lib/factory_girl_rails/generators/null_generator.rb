module FactoryGirlRails
  module Generators
    class NullGenerator
      def initialize(generators)
      end

      def run
      end
    end
  end
end
